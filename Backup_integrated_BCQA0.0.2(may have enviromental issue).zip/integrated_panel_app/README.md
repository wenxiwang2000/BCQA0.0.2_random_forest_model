# Morphology Analyzer (Panel Edition)

This repository contains an integrated morphology analysis application built with **Panel**, offering a unified interface for training a Random Forest classifier and applying it to automatically filter non‑cell objects in bright‑field microscopy images.  It combines the data collection, model training and detection workflows into a single user‑friendly app.

## Features

* **Training panel** — Upload CSV files of measured cell and non‑cell features to train a RandomForest classifier.  The app automatically drops accidental index columns (e.g. `Unnamed: 0`), splits the data into training and test sets, reports accuracy/ROC/feature importance and lets you download the trained model as a `.joblib` file.

* **Detection panel** — Upload a microscopy image and optionally a trained Random Forest model.  You can adjust segmentation parameters (threshold type, kernel sizes, minimum area).  The app segments the image, measures cell morphology (including **Equivalent Diameter** and **Convex Area** from the literature【185†L516-L581】), applies the classifier to remove objects predicted as non‑cells and displays the results:
  * Heatmap overlay with greyscale shading proportional to thickness
  * Interactive table of measured properties
  * Colour bar indicating relative thickness
  * Download buttons for the CSV results and overlay image

* **Integrated UI without Streamlit** — The application uses [Panel](https://panel.holoviz.org/) instead of Streamlit, providing a more flexible, multi‑tab interface without requiring a running Streamlit server.  It can run locally via `panel serve`.

## Installation & Running

1. Extract the archive and navigate into the `integrated_panel_app` directory.
2. Install the required Python packages:

   ```bash
   pip install -r requirements.txt
   ```

3. Launch the application via the provided scripts:

   * On Linux/macOS:

     ```bash
     ./run_app.sh
     ```

   * On Windows (Command Prompt):

     ```cmd
     run_app.bat
     ```

   The command opens a browser tab with the Panel interface.

## Training Workflow

1. Click the **Train** tab.
2. Use the **Cell CSV** inputs to upload one or more CSV files containing measurements for true cells.  Use the **Non‑cell CSV** inputs for measurements of non‑cell objects (e.g. debris).  Each file should include numeric feature columns; labels are assigned automatically.
3. Click **Train Random Forest**.  The app concatenates the datasets, removes `Unnamed` columns, trains a model, shows evaluation plots and provides a **Download Model** button.

## Detection Workflow

1. Click the **Detect** tab.
2. Upload a microscope image (PNG/JPG/TIFF).  Adjust segmentation parameters if necessary.
3. (Optional) Upload a `.joblib` model trained in the **Train** tab.  If provided, the model will classify each detected object as cell (1) or non‑cell (0) and filter accordingly.
4. Click **Process Image**.  The app shows a heatmap overlay, a colour bar, an interactive table of measured properties and download buttons for the CSV and overlay image.

## Notes

* The classifier uses only the numeric feature columns shared between the training data and the new measurements.  If you encounter a feature mismatch error, ensure your training CSVs do not contain accidental index columns or extra columns not present in the detection table.
* The segmentation and measurement routines are adapted from the BCQA pipeline, including morphological operations and thickness estimation.
* Panel stores uploaded files in memory; for very large datasets, consider splitting files or increasing browser/server limits.

## License

This project is provided under the MIT License.