#!/bin/bash
# Run the Morphology Analyzer Panel app
# Install required packages and launch the application in a browser.

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$SCRIPT_DIR"

if [ -f requirements.txt ]; then
    python3 -m pip install --upgrade pip
    python3 -m pip install -r requirements.txt
fi

exec panel serve main.py --autoreload --show