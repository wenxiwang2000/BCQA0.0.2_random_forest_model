@echo off
REM Run the Morphology Analyzer Panel app on Windows
cd %~dp0
if exist requirements.txt (
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt
)
panel serve main.py --autoreload --show