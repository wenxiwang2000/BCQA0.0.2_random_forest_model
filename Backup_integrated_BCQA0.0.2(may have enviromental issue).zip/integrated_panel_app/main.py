"""
Integrated morphology analysis and Random Forest training/detection app
---------------------------------------------------------------------

This Panel application combines training and detection into a single user
interface.  Users can upload parameter CSV files for **cell** and **non‑cell**
objects, train a RandomForest classifier on those features (dropping
any accidental index columns), evaluate performance, and download the
trained model.  Users can also upload a microscopy image and a trained
model file to perform segmentation, feature extraction and automatic
filtering of non‑cell objects.  The results include an overlay image,
a table of measured properties and download links for the CSV and
overlay image.

Usage:
    panel serve main.py --show

Dependencies are listed in requirements.txt.
"""

import io
import os
import zipfile
from typing import List, Tuple, Optional

import cv2
import joblib
import numpy as np
import pandas as pd
import panel as pn
from PIL import Image
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc
from sklearn.model_selection import train_test_split

pn.extension('vega')

# -----------------------------------------------------------------------------
# Segmentation and feature extraction utilities (adapted from the BCQA app)
#
def segment_cells(
    bgr: np.ndarray,
    method: str = "Otsu",
    block_size: int = 31,
    offset_c: int = 10,
    open_k: int = 2,
    close_k: int = 4,
) -> np.ndarray:
    """Segment cells using Otsu or adaptive thresholding.

    Parameters
    ----------
    bgr : np.ndarray
        Colour image in BGR order.
    method : str
        'Otsu' for global Otsu threshold, or 'Adaptive' for local adaptive mean.
    block_size : int
        Size of the neighbourhood used in adaptive threshold (must be odd).
    offset_c : int
        Constant subtracted from the mean in adaptive thresholding.
    open_k : int
        Kernel size for morphological opening (noise removal).
    close_k : int
        Kernel size for morphological closing (hole filling/fragment connection).

    Returns
    -------
    np.ndarray
        Binary mask (uint8) with segmented foreground (cells) = 255.
    """
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    if method == "Adaptive":
        bs = max(3, int(block_size))
        if bs % 2 == 0:
            bs += 1
        bw = cv2.adaptiveThreshold(
            gray,
            255,
            cv2.ADAPTIVE_THRESH_MEAN_C,
            cv2.THRESH_BINARY_INV,
            bs,
            int(offset_c),
        )
    else:
        # Otsu threshold (inverse binary)
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    # Morphological opening
    if open_k and open_k > 1:
        k = np.ones((open_k, open_k), np.uint8)
        bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN, k, iterations=1)
    # Morphological closing
    if close_k and close_k > 1:
        k = np.ones((close_k, close_k), np.uint8)
        bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, k, iterations=1)
    return bw


def measure_cells(
    bgr: np.ndarray, bw: np.ndarray, min_area: float = 50.0
) -> Tuple[List[dict], np.ndarray, float, float, dict]:
    """Measure morphological features and generate greyscale heatmap overlay.

    Returns a list of feature dictionaries, the overlay image, the minimum and
    maximum mean intensities and a mapping from contour index to grey value.

    This function computes additional features (Equivalent_Diameter,
    Convex_Area) to enrich the morphology descriptor.  Features returned are:

      - Cell_ID
      - Area
      - Perimeter
      - Circularity
      - Mean_Fluorescence (mean grayscale value)
      - Aspect_Ratio
      - Equivalent_Diameter
      - Convex_Area
      - Grey_Value (for heatmap)
      - X, Y, Width, Height (bounding box)

    Parameters
    ----------
    bgr : np.ndarray
        Original colour image (BGR).
    bw : np.ndarray
        Binary mask of segmented cells (values 0 or 255).
    min_area : float
        Minimum area to accept an object as a cell.

    Returns
    -------
    rows : List[dict]
        List of dictionaries representing per-cell measurements.
    overlay : np.ndarray
        BGR image with greyscale cell fills and green outlines.
    min_int : float
        Minimum mean intensity across cells (for colour bar mapping).
    max_int : float
        Maximum mean intensity across cells.
    grey_map : dict
        Mapping from contour index to grey value used for overlay.
    """
    h, w = bw.shape
    contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    rows: List[dict] = []
    overlay = bgr.copy()
    gray_img = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    intensities = []
    cell_indices = []
    cell_masks: List[np.ndarray] = []
    # Collect mean intensities and masks
    for idx, c in enumerate(contours):
        area = float(cv2.contourArea(c))
        if area < min_area:
            continue
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.drawContours(mask, [c], -1, 255, thickness=-1)
        mean_intensity = float(cv2.mean(gray_img, mask=mask)[0])
        intensities.append(mean_intensity)
        cell_indices.append(idx)
        cell_masks.append(mask)
    if not intensities:
        return rows, overlay, 0.0, 0.0, {}
    min_int = float(min(intensities))
    max_int = float(max(intensities))
    if max_int == min_int:
        max_int += 1.0
    grey_map: dict[int, int] = {}
    # Map intensity to grey value (200 for thin → 50 for thick)
    for idx, mean_intensity, mask in zip(cell_indices, intensities, cell_masks):
        grey_val = int(np.interp(mean_intensity, [min_int, max_int], [200, 50]))
        grey_map[idx] = grey_val
        overlay[mask == 255] = (grey_val, grey_val, grey_val)
    # Draw outlines and measure features
    normal_colour = (128, 255, 128)
    for idx, c in enumerate(contours):
        area = float(cv2.contourArea(c))
        if area < min_area:
            continue
        cv2.drawContours(overlay, [c], -1, normal_colour, thickness=1)
        perimeter = float(cv2.arcLength(c, True))
        if perimeter <= 0.0:
            continue
        x, y, wc, hc = cv2.boundingRect(c)
        circ = float(4.0 * np.pi * area / (perimeter ** 2))
        aspect_ratio = float(wc) / float(hc) if hc > 0 else 0.0
        # Equivalent diameter: diameter of a circle with same area
        eq_diameter = float(np.sqrt(4.0 * area / np.pi))
        # Convex area: area of convex hull
        hull = cv2.convexHull(c)
        convex_area = float(cv2.contourArea(hull))
        # Mean intensity for contour region
        mean_intensity = float(
            cv2.mean(
                gray_img,
                mask=cv2.drawContours(np.zeros_like(bw), [c], -1, 255, thickness=-1),
            )[0]
        )
        rows.append(
            {
                "Cell_ID": idx,
                "Area": area,
                "Perimeter": perimeter,
                "Circularity": circ,
                "Mean_Fluorescence": mean_intensity,
                "Aspect_Ratio": aspect_ratio,
                "Equivalent_Diameter": eq_diameter,
                "Convex_Area": convex_area,
                "Grey_Value": grey_map.get(idx, 0),
                "X": x,
                "Y": y,
                "Width": wc,
                "Height": hc,
            }
        )
    return rows, overlay, min_int, max_int, grey_map


def create_colour_bar(min_int: float, max_int: float) -> Image.Image:
    """Create a greyscale colour bar indicating thin → thick intensities."""
    width, height = 256, 50
    bar = np.zeros((height, width, 3), dtype=np.uint8)
    for i in range(width):
        grey_val = int(np.interp(i, [0, width - 1], [200, 50]))
        bar[:, i] = (grey_val, grey_val, grey_val)
    # annotate with min/max
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(bar, f"thin ({min_int:.1f})", (5, height - 10), font, 0.4, (0, 0, 0), 1, cv2.LINE_AA)
    text = f"thick ({max_int:.1f})"
    text_size = cv2.getTextSize(text, font, 0.4, 1)[0]
    cv2.putText(bar, text, (width - text_size[0] - 5, height - 10), font, 0.4, (0, 0, 0), 1, cv2.LINE_AA)
    return Image.fromarray(bar)


# -----------------------------------------------------------------------------
# Training and Detection panels
#

def load_csvs_from_fileinputs(inputs: List[pn.widgets.FileInput]) -> Optional[pd.DataFrame]:
    """Concatenate multiple CSVs from Panel FileInput widgets.

    Parameters
    ----------
    inputs : list of FileInput
        FileInput widgets containing CSV bytes; only non-empty values are read.

    Returns
    -------
    pd.DataFrame | None
        Concatenated DataFrame or None if no files were supplied.
    """
    dfs = []
    for finput in inputs:
        if finput.value is not None:
            try:
                data = io.BytesIO(finput.value)
                df = pd.read_csv(data)
                dfs.append(df)
            except Exception:
                return None
    if not dfs:
        return None
    return pd.concat(dfs, ignore_index=True)


def drop_index_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Drop any columns that look like index columns (e.g. Unnamed: 0)."""
    return df.loc[:, ~df.columns.str.contains("^Unnamed")]


class MorphologyApp:
    """Integrated app for training and detection using Panel."""

    def __init__(self):
        # Training widgets
        self.cell_inputs = [pn.widgets.FileInput(name=f"Cell CSV {i+1}", accept='.csv') for i in range(2)]
        self.noncell_inputs = [pn.widgets.FileInput(name=f"Non‑cell CSV {i+1}", accept='.csv') for i in range(2)]
        self.train_button = pn.widgets.Button(name="Train Random Forest", button_type="primary")
        self.train_button.on_click(self.train_model)
        self.train_output = pn.Column()
        # Detection widgets
        self.image_input = pn.widgets.FileInput(name="Upload Image", accept=".png,.jpg,.jpeg,.tif,.tiff")
        self.model_input = pn.widgets.FileInput(name="Load Random Forest Model", accept=".joblib,.pkl")
        self.method_select = pn.widgets.Select(name="Threshold Method", options=["Otsu", "Adaptive"], value="Otsu")
        self.block_slider = pn.widgets.IntSlider(name="Adaptive Block Size", start=3, end=101, step=2, value=31)
        self.offset_slider = pn.widgets.IntSlider(name="Adaptive Offset C", start=0, end=30, step=1, value=10)
        self.open_slider = pn.widgets.IntSlider(name="Opening Kernel", start=0, end=10, step=1, value=2)
        self.close_slider = pn.widgets.IntSlider(name="Closing Kernel", start=0, end=10, step=1, value=4)
        self.min_area = pn.widgets.FloatInput(name="Minimum Area", value=50.0, step=1.0)
        self.process_button = pn.widgets.Button(name="Process Image", button_type="primary")
        self.process_button.on_click(self.process_image)
        self.detect_output = pn.Column()
        # Build layout
        self.train_panel = pn.Column(
            pn.pane.Markdown("## 🧬 Train Random Forest\nUpload your cell and non‑cell feature tables."),
            pn.Row(*self.cell_inputs),
            pn.Row(*self.noncell_inputs),
            self.train_button,
            self.train_output,
        )
        self.detect_panel = pn.Column(
            pn.pane.Markdown("## 🔎 Detect Cells and Filter with Random Forest"),
            self.image_input,
            self.model_input,
            self.method_select,
            self.block_slider,
            self.offset_slider,
            pn.Row(self.open_slider, self.close_slider),
            self.min_area,
            self.process_button,
            self.detect_output,
        )
        self.tabs = pn.Tabs(("Train", self.train_panel), ("Detect", self.detect_panel))

    # -------------------------------------------------------------------------
    # Training callback
    #
    def train_model(self, event):
        """Train a RandomForest model from uploaded CSVs."""
        self.train_output.clear()
        # Load cell and non-cell data
        cell_df = load_csvs_from_fileinputs(self.cell_inputs)
        non_df = load_csvs_from_fileinputs(self.noncell_inputs)
        if cell_df is None or non_df is None:
            self.train_output.append(pn.pane.Alert("Please upload valid CSV files for both categories.", alert_type="danger"))
            return
        # Drop index columns
        cell_df = drop_index_columns(cell_df)
        non_df = drop_index_columns(non_df)
        # Add label column
        cell_df["Label"] = 1
        non_df["Label"] = 0
        # Combine
        data = pd.concat([cell_df, non_df], ignore_index=True)
        # Use only numeric columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
        if "Label" in numeric_cols:
            numeric_cols.remove("Label")
        if not numeric_cols:
            self.train_output.append(pn.pane.Alert("No numeric feature columns found.", alert_type="danger"))
            return
        X = data[numeric_cols].fillna(0)
        y = data["Label"]
        # Train/test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        # Fit model
        rf = RandomForestClassifier(n_estimators=100, random_state=42)
        rf.fit(X_train, y_train)
        # Evaluate
        y_pred = rf.predict(X_test)
        y_prob = rf.predict_proba(X_test)[:, 1]
        report = classification_report(y_test, y_pred, output_dict=True)
        cm = confusion_matrix(y_test, y_pred)
        fpr, tpr, thresholds = roc_curve(y_test, y_prob)
        roc_auc = auc(fpr, tpr)
        # Build outputs
        report_md = pn.pane.Markdown(f"### Classification Report\n```
{pd.DataFrame(report).transpose().to_string()}\n```")
        cm_plot = pn.pane.Matplotlib()
        import matplotlib.pyplot as plt
        import seaborn as sns
        fig_cm, ax_cm = plt.subplots()
        sns.heatmap(
            cm,
            annot=True,
            fmt="d",
            cmap="Blues",
            xticklabels=["Non-cell", "Cell"],
            yticklabels=["Non-cell", "Cell"],
            ax=ax_cm,
        )
        ax_cm.set_xlabel("Predicted")
        ax_cm.set_ylabel("True")
        cm_plot.object = fig_cm
        roc_plot = pn.pane.Matplotlib()
        fig_roc, ax_roc = plt.subplots()
        ax_roc.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
        ax_roc.plot([0, 1], [0, 1], "k--")
        ax_roc.set_xlabel("False Positive Rate")
        ax_roc.set_ylabel("True Positive Rate")
        ax_roc.set_title("ROC Curve")
        ax_roc.legend(loc="lower right")
        roc_plot.object = fig_roc
        # Feature importance barplot
        importances = rf.feature_importances_
        indices = np.argsort(importances)[::-1]
        imp_plot = pn.pane.Matplotlib()
        fig_imp, ax_imp = plt.subplots()
        sns.barplot(x=importances[indices], y=[numeric_cols[i] for i in indices], ax=ax_imp)
        ax_imp.set_xlabel("Importance")
        ax_imp.set_ylabel("Feature")
        imp_plot.object = fig_imp
        # Save model to bytes
        buffer = io.BytesIO()
        joblib.dump(rf, buffer)
        buffer.seek(0)
        download_button = pn.widgets.FileDownload(
            file=buffer.getvalue(),
            filename="rf_model.joblib",
            button_label="Download Model (.joblib)",
            embed=True,
        )
        # Display
        self.train_output.append(report_md)
        self.train_output.append(cm_plot)
        self.train_output.append(roc_plot)
        self.train_output.append(imp_plot)
        self.train_output.append(download_button)

    # -------------------------------------------------------------------------
    # Detection callback
    #
    def process_image(self, event):
        """Run segmentation, extract features and apply RF filtering if provided."""
        self.detect_output.clear()
        if self.image_input.value is None:
            self.detect_output.append(pn.pane.Alert("Please upload an image.", alert_type="danger"))
            return
        # Load image
        try:
            image_data = io.BytesIO(self.image_input.value)
            pil_img = Image.open(image_data)
        except Exception as e:
            self.detect_output.append(pn.pane.Alert(f"Error loading image: {e}", alert_type="danger"))
            return
        bgr = cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)
        # Determine parameters
        method = self.method_select.value
        block_size = self.block_slider.value
        offset_c = self.offset_slider.value
        open_k = self.open_slider.value
        close_k = self.close_slider.value
        min_area = self.min_area.value
        # Segment
        bw = segment_cells(bgr, method, block_size, offset_c, open_k, close_k)
        rows, overlay, min_int, max_int, grey_map = measure_cells(bgr, bw, min_area)
        if not rows:
            self.detect_output.append(pn.pane.Alert("No cells detected. Adjust parameters.", alert_type="warning"))
            return
        df = pd.DataFrame(rows)
        # If model file uploaded, load and predict
        if self.model_input.value is not None:
            try:
                model_buffer = io.BytesIO(self.model_input.value)
                rf_model = joblib.load(model_buffer)
            except Exception as e:
                self.detect_output.append(pn.pane.Alert(f"Error loading model: {e}", alert_type="danger"))
                return
            try:
                numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
                # Exclude Grey_Value as it's only for display
                if "Grey_Value" in numeric_cols:
                    numeric_cols.remove("Grey_Value")
                # Align to model's expected features if available
                feature_cols = numeric_cols.copy()
                if hasattr(rf_model, 'feature_names_in_'):
                    feature_cols = [col for col in rf_model.feature_names_in_ if col in df.columns]
                X_pred = df[feature_cols].fillna(0)
                preds = rf_model.predict(X_pred)
                keep_mask = preds == 1
                removed_count = int((~keep_mask).sum())
                df = df.loc[keep_mask].reset_index(drop=True)
                if removed_count > 0:
                    self.detect_output.append(pn.pane.Alert(f"Removed {removed_count} objects predicted as non‑cell.", alert_type="info"))
            except Exception as e:
                self.detect_output.append(pn.pane.Alert(f"Error applying model: {e}", alert_type="danger"))
        # Show overlay
        overlay_rgb = cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB)
        # Convert overlay to PNG bytes
        overlay_pil = Image.fromarray(overlay_rgb)
        buf = io.BytesIO()
        overlay_pil.save(buf, format="PNG")
        buf.seek(0)
        overlay_pane = pn.pane.Image(overlay_pil, embed=True)
        # Create colour bar
        colour_bar = create_colour_bar(min_int, max_int)
        colour_bar_pane = pn.pane.Image(colour_bar, embed=True)
        # Display DataFrame
        df_pane = pn.widgets.Tabulator(df)
        # File downloads
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_download = pn.widgets.FileDownload(
            file=csv_buffer.getvalue().encode('utf-8'),
            filename="cell_measurements.csv",
            button_label="Download CSV",
            embed=True,
        )
        overlay_download = pn.widgets.FileDownload(
            file=buf.getvalue(),
            filename="overlay.png",
            button_label="Download Overlay Image",
            embed=True,
        )
        # Compose detection output
        self.detect_output.append(pn.pane.Markdown("### Overlay Image"))
        self.detect_output.append(overlay_pane)
        self.detect_output.append(colour_bar_pane)
        self.detect_output.append(pn.pane.Markdown("### Measured Properties"))
        self.detect_output.append(df_pane)
        self.detect_output.append(pn.Row(csv_download, overlay_download))

    def view(self):
        return self.tabs


# Instantiate and serve the app
app = MorphologyApp()
pn.config.raw_css.append(".bk-pane-alert { margin-top: 0.5em; }")
pn.serve(app.view, title="Morphology Analyzer", show=False)